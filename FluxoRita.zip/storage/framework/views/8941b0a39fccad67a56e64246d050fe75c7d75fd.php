<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading"><br>
					<nav>
						<div class="nav-wrapper deep-purple darken-4 z-depth-5">
							<div class="col s12">
								<a class="breadcrumb">Fluxo de Caixa</a>
								<a class="breadcrumb">Relatórios</a>
								<a class="breadcrumb">Fluxo</a>
							</div>
						</div>
					</nav><br>		
				</div>
				<div class="panel-body">
					<div class="card">
						<div class="card-content">
							<div class="row">
                               <form method="POST" action="<?php echo e(route('fluxo.search')); ?> ">
							   <?php echo e(csrf_field()); ?>

							   <div class="input-field col s5 ">
									<select name="ano" class="validate">
									<option value="" disabled selected>Escolha o Ano</option>
                                                <?php $__currentLoopData = $anos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ano): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($ano->ANO); ?>"><?php echo e($ano->ANO); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<label>Ano</label>
								</div>
								<div class="input-field col s5 ">
									<select name="mes" class="validate">
									<option value="" disabled selected>Escolha o Mes</option>
									
												<?php for($i = 1; $i <= 12; $i++): ?>
												
                                              <option value="<?php echo e($i); ?>"><?php echo e(strftime('%B', strtotime($i.'/06/2019'))); ?></option>
                                                <?php endfor; ?>
									</select>
									<label>Mes</label>
								</div>

								<div class="col s2">
									<button type="submit" class="right modal-trigger btn-floating  COL S2" >
										<i class=" material-icons blue white-text circle" >search</i>
									</button>
								</div>
								</form>
							<a name="Toast"></a>
							</div>
							<div class="row">
							<?php if(isset($aMES)): ?>
							<div class="col s4 m4">
								<div class="card z-depth-5">
									<div class="card-content purple-text">
									<table class="highlight" >
										<thead>
											<tr>
												<th>Dia</th>
												<th>Receita</th>						
												<th>Despesas</th>						
												<th>Ativo</th>						
											</tr>
											<tbody>
											<tr>
											<?php $__currentLoopData = $aMES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($mes[0] == 0) continue; ?>
													<tr>
														<td>Dia <?php echo e($mes[0]); ?> </td>
														<td>R$ <?php echo e($mes[1]); ?> </td>
														<td>R$ <?php echo e($mes[2]); ?> </td>
														<td>R$ <?php echo e($mes[3]); ?> </td>
													<tr>
												<?php if($mes[0] == 10) break; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tr>
											</tbody>
										</thead>
									</table>
									</div>
								</div>
							</div>
							<div class="col s4 m4">
								<div class="card z-depth-5">
									<div class="card-content purple-text">
									<table class="highlight">
										<thead>
											<tr>
												<th>Dia</th>
												<th>Receita</th>						
												<th>Despesas</th>						
												<th>Ativo</th>						
											</tr>
											<tbody>
											<?php $__currentLoopData = $aMES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($mes[0] < 11) continue; ?>
													<tr>
														<td>Dia <?php echo e($mes[0]); ?> </td>
														<td>R$ <?php echo e($mes[1]); ?> </td>
														<td>R$ <?php echo e($mes[2]); ?> </td>
														<td>R$ <?php echo e($mes[3]); ?> </td>
													<tr>
												<?php if($mes[0] == 20) break; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</thead>
									</table>
									</div>
								</div>
							</div>
							<div class="col s4 m4">
								<div class="card z-depth-5">
									<div class="card-content purple-text">
									<table class="highlight">
										<thead>
											<tr>
												<th>Dia</th>
												<th>Receita</th>						
												<th>Despesas</th>						
												<th>Ativo</th>						
											</tr>
											<tbody>
											<?php $__currentLoopData = $aMES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($mes[0] < 21) continue; ?>
													<tr>
														<td>Dia <?php echo e($mes[0]); ?> </td>
														<td>R$ <?php echo e($mes[1]); ?> </td>
														<td>R$ <?php echo e($mes[2]); ?> </td>
														<td>R$ <?php echo e($mes[3]); ?> </td>
													<tr>
												<?php if($mes[0] == 30) break; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

											</tbody>
										</thead>
									</table>
									</div>
								</div>
							</div>
							<?php endif; ?> 
							
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aplicacao\FluxoRita\resources\views/fluxo/um.blade.php ENDPATH**/ ?>