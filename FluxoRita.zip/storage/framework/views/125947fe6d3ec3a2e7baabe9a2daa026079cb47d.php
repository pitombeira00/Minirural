<ul id="_NavCadastro" class="dropdown-content">
      <li><a href="<?php echo e(route('plano.home')); ?>">Plano de Contas</a></li>
      <li><a href="<?php echo e(route('class.home')); ?> ">Classificação</a></li>
      <li><a href="<?php echo e(route('lanca.home')); ?> ">Lançamentos</a></li>
  </ul>
  <!--menu 2-->
   <ul id="_NavMovimentacao" class="dropdown-content">
      <li><a href="<?php echo e(route('fluxo.um')); ?>">Fluxo por Dia</a></li>
      <li><a href="<?php echo e(route('fluxo.Para.anual')); ?>">Fluxo Anual</a></li>
   </ul>
<nav>
    <div class="nav-wrapper white">
        <div class="container">
        <a class="brand-logo left purple-text">Mini Rural</a>
          <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons red lighten-3 ">menu</i></a>
          <ul class="right hide-on-med-and-down">
            <li><a href="<?php echo e(route('home')); ?> " class="deep-purple-text text-darken-2">Inicio</a></li>
            <li><a class="dropdown-button deep-purple-text text-darken-2" href="#!" data-activates="_NavCadastro">Cadastro<i class="material-icons right">arrow_drop_down</i></a></li>
            <li><a class="dropdown-button deep-purple-text text-darken-2" href="#!" data-activates="_NavMovimentacao">Relatórios<i class="material-icons right">arrow_drop_down</i></a></li>
         
          </ul>

             <ul id="mobile-demo" class="side-nav">
            <li><a class="subheader"><i class="material-icons">home</i>Inicio</a></li>
              <li><div class="divider"></div></li>
              <li><a href="#! " class="waves-effect">Gráficos</a></li>
              <li><a class="subheader"><i class="material-icons">contacts</i>Cadastros</a></li>
            </ul>
          </div>
    </div>
</nav>


        <?php /**PATH C:\Aplicacao\FluxoRita\resources\views/layout/menu.blade.php ENDPATH**/ ?>