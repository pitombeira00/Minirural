<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading"><br>
					<nav>
						<div class="nav-wrapper deep-purple darken-4 z-depth-5">
							<div class="col s12">
								<a class="breadcrumb">Fluxo de Caixa</a>
								<a class="breadcrumb">Cadastros</a>
								<a class="breadcrumb">Planos</a>
								<a class="breadcrumb">Incluir</a>
							</div>
						</div>
					</nav><br>		
				</div>
				<div class="panel-body">
					<div class="card">
						<div class="card-content">
                        <h4 class='center'>Criar Plano de Conta</h4>
							<form method="POST" action="<?php echo e(route('plano.store')); ?> ">
								<?php echo e(csrf_field()); ?>

								<div class="row">
							        <div class="input-field col s12">
							          <input name="nome" type="text" class="validate">
							          <label>Nome do Plano de Conta</label>
							        </div>
							    <button type="submit" class="waves-effect green btn right" >Adicionar</button>
						      	<a href="<?php echo e(route('plano.home')); ?> " class="red white-text waves-effect right btn ">Cancelar</a>
								</div>
							</form>

						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aplicacao\FluxoRita\resources\views/Cadastro/plano/create.blade.php ENDPATH**/ ?>