<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--Import Google Icon Font-->
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/materialize/dist/css/materialize.css')); ?>">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <title>Fluxo de Caixa - Rita Maria</title>

    
</head>
<body id="app-layout"  <?php if(Session::has('mensagem')): ?> id="app-layout" onload="Materialize.toast('<?php echo e(Session::get('mensagem')['msg']); ?>', 4000)" <?php endif; ?>>
  <?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>
    

<footer class="page-footer deep-purple darken-4" >
  <div class="footer-copyright">
    <div class="container">
    Produto Mestrado em Extensão Rural, Rita Costa, Orientação Denes Vieira <br> 
    2019 Copy Left, desenvolvido por <a href='http://www.valenext.com.br' >Danilo Pitombeira - danilo.pitombeira@valenext.com.br</a>
    </div>
    
  </div>
</footer>

    <script src="<?php echo e(asset('lib/jquery/dist/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/materialize/dist/js/materialize.js')); ?>"></script>

    <script src="<?php echo e(asset('js/consulta.js')); ?>"></script>
    <script src="<?php echo e(asset('js/init.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Aplicacao\FluxoRita\resources\views/layout/app.blade.php ENDPATH**/ ?>