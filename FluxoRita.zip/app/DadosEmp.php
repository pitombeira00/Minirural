<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DadosEmp extends Model
{
    protected $table = "dados_emp";
    protected $primaryKey = 'id';

}
