<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\lancamentos;
use App\planos;
use App\classificacao;
USE DB;

class FluxoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        date_default_timezone_set('America/Sao_Paulo');
        
        $anos = DB::table('lancamentos')
                    ->select(DB::RAW("YEAR(Data_pagamento) AS ANO"))
                    ->GROUPBY("ANO")
                    ->get();

        return view('Fluxo.um',compact('anos'));
    }

    public function fluxo_um(Request $request)
    {
        $param = $request->all();
        
        setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        date_default_timezone_set('America/Sao_Paulo');
        //select de anos e meses
        
        $anos = DB::table('lancamentos')
        ->select(DB::RAW("YEAR(Data_pagamento) AS ANO"))
        ->GROUPBY("ANO")
        ->get();

        
        $a = 1;
        $aMES = [];
        $nTotDesp = 0;
        $nTotReic = 0;
       
        while ($a <= 30) {
            
            $nReceita = 0;
            $nDespesa = 0;
            $nAtivo = 0;

            $dados = DB::table('lancamentos')
            ->join('plano', 'plano.id', '=', 'lancamentos.id_plano')
            ->join('classificacao', 'classificacao.id', '=', 'lancamentos.id_class')
            ->select(DB::RAW("day(Data_pagamento) AS DIA, sum(valor) AS RECEITA"))
            ->whereRaw("year(Data_pagamento) = '".$param['ano']."'")
            ->whereRaw("month(Data_pagamento) = '".$param['mes']."'")
            ->whereRaw("day(Data_pagamento) = '".$a."'")
            ->where('classificacao.tipo','=','1')
            ->groupBy('valor', 'DIA')
            ->get();
    
            $dados2 = DB::table('lancamentos')
            ->join('plano', 'plano.id', '=', 'lancamentos.id_plano')
            ->join('classificacao', 'classificacao.id', '=', 'lancamentos.id_class')
            ->select(DB::RAW("day(Data_pagamento) AS DIA, sum(valor) AS DESPESA"))
            ->whereRaw("year(Data_pagamento) = '".$param['ano']."'")
            ->whereRaw("month(Data_pagamento) = '".$param['mes']."'")
            ->whereRaw("day(Data_pagamento) = '".$a."'")
            ->where('classificacao.tipo','=','2')
            ->groupBy('valor', 'DIA')
            ->Get();

            $dados3 = DB::table('lancamentos')
            ->join('plano', 'plano.id', '=', 'lancamentos.id_plano')
            ->join('classificacao', 'classificacao.id', '=', 'lancamentos.id_class')
            ->select(DB::RAW("day(Data_pagamento) AS DIA, sum(valor) AS ATIVO"))
            ->whereRaw("year(Data_pagamento) = '".$param['ano']."'")
            ->whereRaw("month(Data_pagamento) = '".$param['mes']."'")
            ->whereRaw("day(Data_pagamento) = '".$a."'")
            ->where('classificacao.tipo','=','3')
            ->groupBy('valor', 'DIA')
            ->Get();

            if (isset($dados[0]->RECEITA)){
                
                $nReceita = $dados[0]->RECEITA;

            }

            if (isset($dados2[0]->DESPESA)){
                
                $nDespesa = $dados2[0]->DESPESA;

            }

            if (isset($dados3[0]->ATIVO)){
                
                $nAtivo = $dados3[0]->ATIVO;

            }
            

            ARRAY_PUSH($aMES,[$a,$nReceita,$nDespesa,$nAtivo]);

            $nTotDesp = $nTotDesp + $nDespesa; 
            $nTotReic = $nTotReic + $nReceita; 
            $a++;
        }

        
        
     
        return view('fluxo.um',compact('aMES', 'anos'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ParaAnual()
    {
        

        $anos = DB::table('lancamentos')
        ->select(DB::RAW("YEAR(Data_pagamento) AS ANO"))
        ->GROUPBY("ANO")
        ->get();


        return view('Fluxo.anual',compact('anos'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function Anual(Request $request)
    {
        $param = $request->all();
        //select de anos e meses
        $anos = DB::table('lancamentos')
        ->select(DB::RAW("YEAR(Data_pagamento) AS ANO"))
        ->GROUPBY("ANO")
        ->get();


        $a = 1;
        $aMES = [];
        $nTotDesp = 0;
        $nTotReic = 0;
        
        while ($a <= 12) {
            
            $nReceita = 0;
            $nDespesa = 0;
            $nAtivo = 0;

            $dados = DB::table('lancamentos')
            ->join('plano', 'plano.id', '=', 'lancamentos.id_plano')
            ->join('classificacao', 'classificacao.id', '=', 'lancamentos.id_class')
            ->select(DB::RAW("sum(valor) as valor"))
            ->whereRaw("year(Data_pagamento) = '".$param['ano']."'")
            ->whereRaw("month(Data_pagamento) = '".$a."'")
            ->where('classificacao.tipo','=','1')
            ->get();
    
            if (isset($dados[0]->valor)){
                
                $nReceita = $dados[0]->valor;
              
            }

            $dados2 = DB::table('lancamentos')
            ->join('plano', 'plano.id', '=', 'lancamentos.id_plano')
            ->join('classificacao', 'classificacao.id', '=', 'lancamentos.id_class')
            ->select(DB::RAW("sum(valor) as valor"))
            ->whereRaw("year(Data_pagamento) = '".$param['ano']."'")
            ->whereRaw("month(Data_pagamento) = '".$a."'")
            ->where('classificacao.tipo','=','2')
            ->get();
    
            if (isset($dados2[0]->valor)){
                
                $nDespesa = $dados2[0]->valor;
              
            }

            $dados3 = DB::table('lancamentos')
            ->join('plano', 'plano.id', '=', 'lancamentos.id_plano')
            ->join('classificacao', 'classificacao.id', '=', 'lancamentos.id_class')
            ->select(DB::RAW("sum(valor) as valor"))
            ->whereRaw("year(Data_pagamento) = '".$param['ano']."'")
            ->whereRaw("month(Data_pagamento) = '".$a."'")
            ->where('classificacao.tipo','=','3')
            ->get();
    
            if (isset($dados3[0]->valor)){
                
                $nAtivo = $dados3[0]->valor;
              
            }

           
            

            ARRAY_PUSH($aMES,[$a,$nReceita,$nDespesa,$nAtivo]);

           // $nTotDesp = $nTotDesp + $nDespesa; 
            $nTotReic = $nTotReic + $nReceita; 
            $a++;
        }

             
        return view('fluxo.anual',compact('aMES', 'anos'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
